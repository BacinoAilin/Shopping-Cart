﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Text;

namespace Repositories
{
   public interface IConnection
    {
        void Open();
        void Close();

        DbCommand CreateCommand();
    }
}
