﻿using Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
/*  Linq es una libreria nativa de .net, que me permite realizar operaciones similares en cuanto a sintaxis
            de query de sql pero hacerlo en el código sobre colecciones de memoria.
*/
using System.Text;

namespace Repositories
{
    public class ProductRepository : IProductRepository
    {
        private static ProductRepository instance = null; // El repositorio debe ser una sola instancia siempre. Esto hace que la lista sea una sola instancia también, que no se creen múltiples listas.

        private IList<Product> products = new List<Product>();

        private IConnection connection = new Connection();
       
        public static IProductRepository GetInstance() //Devolveme la instancia
        {
            try
            {
                if (instance == null) //Si no hay una instancia creada, la va a crear y la va a devolver
                    instance = new ProductRepository();
            }catch (Exception ex)
            {
                throw ex;    
            }

            return instance; //Si hay una instancia creada, me devuelve la que ya está creada.
        }

        //A esto se lo denomina Singleton Pattern - Patron de diseño para modelar clases. Me ayuda a que una clase devuelva una y solo una instancia.
        public void Add(Product product)
        {
           try
            {
            
            var insertCommand = connection.CreateCommand();

            insertCommand.CommandText = "INSERT INTO Products(Category_Id, Name, Description, Price, Image_Url) VALUES (@Category_Id, @Name, @Description, @Price, @Image_Url)";

            var CategoryIdParam = insertCommand.CreateParameter();
            CategoryIdParam.ParameterName = "Category_Id";
            CategoryIdParam.DbType = DbType.Int32;
            CategoryIdParam.Value = product.Category_Id;
            insertCommand.Parameters.Add(CategoryIdParam);

            var NameParam = insertCommand.CreateParameter();
            NameParam.ParameterName = "Name";
            NameParam.DbType = DbType.String;
            NameParam.Size = 100;
            NameParam.Value = product.Name;
            insertCommand.Parameters.Add(NameParam);

            var DescriptionParam = insertCommand.CreateParameter();
            DescriptionParam.ParameterName = "Description";
            DescriptionParam.DbType = DbType.String;
            DescriptionParam.Size = 200;
            DescriptionParam.Value = product.Description;
            insertCommand.Parameters.Add(DescriptionParam);

            var PriceParam = insertCommand.CreateParameter();
            PriceParam.ParameterName = "Price";
            PriceParam.DbType = DbType.Double;
            PriceParam.Value = product.Price;
            insertCommand.Parameters.Add(PriceParam);

            var ImageUrlParam = insertCommand.CreateParameter();
            ImageUrlParam.ParameterName = "Image_Url";
            ImageUrlParam.DbType = DbType.String;
            ImageUrlParam.Size = 200;
            ImageUrlParam.Value = product.Image_Url;
            insertCommand.Parameters.Add(ImageUrlParam);

            

            connection.Open();

            insertCommand.Prepare();

            insertCommand.ExecuteNonQuery();

            connection.Close();

           

            }
            catch (Exception ex)
            {
                throw ex;
            }
            //products.Add(product);

        }

        public IList<Product> GetAll()
        {

            IList<Product> productList = new List<Product>();

            try
            {
                var command = connection.CreateCommand();
                command.CommandText = "SELECT Id, Category_Id, Name, Description, Price, Image_Url FROM Products";
                connection.Open();
                command.Prepare();

                var dataReader = command.ExecuteReader();
                while(dataReader.Read())
                {
                    var product = new Product();
                    product.Id = dataReader.GetInt32(0);
                    product.Category_Id = dataReader.GetInt32(1);
                    product.Name = dataReader.GetString(2);
                    product.Description = dataReader.GetString(3);
                    product.Price = dataReader.GetDouble(4);
                    product.Image_Url = dataReader.GetString(5);

                    productList.Add(product);

                }

                dataReader.Close();

                connection.Close();

                
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return productList;
        }

        public Product GetByName(string name)
        {
            Product p = new Product();

            try
            {
                var command = connection.CreateCommand();

                command.CommandText = "SELECT Id, Category_Id, Name, Description, Price, Image_Url FROM Products WHERE Name = @Name ";

                var NameParam = command.CreateParameter();
                NameParam.ParameterName = "Name";
                NameParam.DbType = DbType.String;
                NameParam.Size = 100;
                NameParam.Value = name;
                command.Parameters.Add(NameParam);

                connection.Open();

                command.Prepare();

                var dataReader = command.ExecuteReader();

                while (dataReader.Read())
                {
                    p.Id = dataReader.GetInt32(0);
                    p.Category_Id = dataReader.GetInt32(1);
                    p.Name = dataReader.GetString(2);
                    p.Description = dataReader.GetString(3);
                    p.Price = dataReader.GetDouble(4);
                    p.Image_Url = dataReader.GetString(5);
                }

                dataReader.Close();

                connection.Close();


            }
            catch (Exception ex)
            {
                throw ex;
            }

            return p;
        }

        public void Delete(int id)
        {
            try
            {
                var command = connection.CreateCommand();

                command.CommandText = "DELETE FROM Products WHERE Id = @Id";

                var IdParam = command.CreateParameter();
                IdParam.ParameterName = "Id";
                IdParam.DbType = DbType.Int32;
                IdParam.Value = id;
                command.Parameters.Add(IdParam);

                connection.Open();

                command.Prepare();

                command.ExecuteNonQuery();

                connection.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            
        }


        public bool CategoryId(int id)
        {
            bool result = false;
            try
            {

                var command = connection.CreateCommand();

                command.CommandText = "SELECT Category_Id FROM Products WHERE Category_Id = @Category_Id";

                var IdParam = command.CreateParameter();
                IdParam.ParameterName = "Category_Id";
                IdParam.DbType = DbType.Int32;
                IdParam.Value = id;
                command.Parameters.Add(IdParam);

                connection.Open();

                command.Prepare();

                var dataReader = command.ExecuteReader();

                while (dataReader.Read())
                {
                   
                    result = true;

                }
                    
                dataReader.Close();

                connection.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }
        public int GetCategoryID(int id)
        {

            Product p = new Product();
            int x;

            try
            {

                var command = connection.CreateCommand();

                command.CommandText = "SELECT Id, Category_Id FROM Products WHERE Id = @Id ";

                var IdParam = command.CreateParameter();
                IdParam.ParameterName = "Id";
                IdParam.DbType = DbType.Int32;
                IdParam.Value = id;
                command.Parameters.Add(IdParam);

                connection.Open();

                command.Prepare();

                var dataReader = command.ExecuteReader();

                while (dataReader.Read())
                {
                    p.Id = dataReader.GetInt32(0);
                    p.Category_Id = dataReader.GetInt32(1);
                   
                }

                dataReader.Close();

                connection.Close();

                x = p.Category_Id;

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return x;

        }

        public Product GetByID(int id)
        {

            Product p = new Product();

            try
            {

                var command = connection.CreateCommand();

                command.CommandText = "SELECT Id, Category_Id, Name, Description, Price, Image_Url FROM Products WHERE Id = @Id ";

                var IdParam = command.CreateParameter();
                IdParam.ParameterName = "Id";
                IdParam.DbType = DbType.Int32;
                IdParam.Value = id;
                command.Parameters.Add(IdParam);

                connection.Open();

                command.Prepare();

                var dataReader = command.ExecuteReader();

                while (dataReader.Read())
                {
                    p.Id = dataReader.GetInt32(0);
                    p.Category_Id = dataReader.GetInt32(1);
                    p.Name = dataReader.GetString(2);
                    p.Description = dataReader.GetString(3);
                    p.Price = dataReader.GetDouble(4);
                    p.Image_Url = dataReader.GetString(5);
                }

                dataReader.Close();

                connection.Close();

                
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return p;
           
        }

        public void Modify(Product product)
        {
            try
            {

                var insertCommand = connection.CreateCommand();

                insertCommand.CommandText = "UPDATE Products SET Category_Id = @Category_Id, Name = @Name, Description = @Description, Price = @Price, Image_Url = @Image_Url WHERE Id = @Id";


                var IdParam = insertCommand.CreateParameter();
                IdParam.ParameterName = "Id";
                IdParam.DbType = DbType.Int32;
                IdParam.Value = product.Id;
                insertCommand.Parameters.Add(IdParam);

                var CategoryIdParam = insertCommand.CreateParameter();
                CategoryIdParam.ParameterName = "Category_Id";
                CategoryIdParam.DbType = DbType.Int32;
                CategoryIdParam.Value = product.Category_Id;
                insertCommand.Parameters.Add(CategoryIdParam);

                var NameParam = insertCommand.CreateParameter();
                NameParam.ParameterName = "Name";
                NameParam.DbType = DbType.String;
                NameParam.Size = 100;
                NameParam.Value = product.Name;
                insertCommand.Parameters.Add(NameParam);

                var DescriptionParam = insertCommand.CreateParameter();
                DescriptionParam.ParameterName = "Description";
                DescriptionParam.DbType = DbType.String;
                DescriptionParam.Size = 200;
                DescriptionParam.Value = product.Description;
                insertCommand.Parameters.Add(DescriptionParam);

                var PriceParam = insertCommand.CreateParameter();
                PriceParam.ParameterName = "Price";
                PriceParam.DbType = DbType.Double;
                PriceParam.Value = product.Price;
                insertCommand.Parameters.Add(PriceParam);

                var ImageUrlParam = insertCommand.CreateParameter();
                ImageUrlParam.ParameterName = "Image_Url";
                ImageUrlParam.DbType = DbType.String;
                ImageUrlParam.Size = 200;
                ImageUrlParam.Value = product.Image_Url;
                insertCommand.Parameters.Add(ImageUrlParam);



                connection.Open();

                insertCommand.Prepare();

                insertCommand.ExecuteNonQuery();

                connection.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            
        }
    }
}
