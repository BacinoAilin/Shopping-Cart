﻿using Models;
using System;
using System.Collections.Generic;
using System.Reflection.Metadata;
using System.Text;

namespace Repositories
{
    public class UserTypeRepository : IUserTypeRepository
    {
        //private UserType type1 = new UserType();
        //private UserType type2 = new UserType();
        private static UserTypeRepository instance = null;
        private IConnection connection = new Connection();
        private IList<UserType> usersT = new List<UserType>();

        //public void Add()
        //{
        //    type1.Name = "Admin";
        //    type2.Name = "Client";
        //    usersT.Add(type1);
        //    usersT.Add(type2);
        //}
        public static IUserTypeRepository GetInstance() 
        {
            try
            {
                if (instance == null) 
                    instance = new UserTypeRepository();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return instance; 
        }
        public IList<UserType> GetAll()
        {
            IList<UserType> usersTList = new List<UserType>();

            try
            {
                var command = connection.CreateCommand();
                command.CommandText = "SELECT UserType_Id, Name FROM UserType";
                connection.Open();
                command.Prepare();

                var dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    var userT = new UserType();
                    userT.UserType_Id = dataReader.GetInt32(0);
                    userT.Name = dataReader.GetString(1);
                    usersTList.Add(userT);

                }

                dataReader.Close();

                connection.Close();


            }
            catch (Exception ex)
            {
                throw ex;
            }

            return usersTList;
        }
    }
}
