﻿using Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;


namespace Repositories
{
    public class ProductCategoryRepository : IProductCategoryRepository
    {
        private IList<ProductCategory> productsCategory = new List<ProductCategory>();
        private IList<Product> products = new List<Product>();
        private IConnection connection = new Connection();

        public void Add(ProductCategory productC)
        {
            try
            {
                var insertCommand = connection.CreateCommand();

                insertCommand.CommandText = "INSERT INTO ProductCategory (Name) VALUES (@Name)";

                var NameParam = insertCommand.CreateParameter();
                NameParam.ParameterName = "Name";
                NameParam.DbType = DbType.String;
                NameParam.Size = 100;
                NameParam.Value = productC.Name;
                insertCommand.Parameters.Add(NameParam);


                connection.Open();

                insertCommand.Prepare();

                insertCommand.ExecuteNonQuery();

                connection.Close();



            }
            catch (Exception ex)
            {
                throw ex;
            }

          //  productsCategory.Add(productC);

        }

        public void Remove(int id)
        {

            try
            {
                var command = connection.CreateCommand();

                command.CommandText = "DELETE FROM ProductCategory WHERE Category_Id = @Category_Id";

                var IdParam = command.CreateParameter();
                IdParam.ParameterName = "Category_Id";
                IdParam.DbType = DbType.Int32;
                IdParam.Value = id;
                command.Parameters.Add(IdParam);

                connection.Open();

                command.Prepare();

                command.ExecuteNonQuery();

                connection.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public IList<ProductCategory> GetAll()
        {
            IList<ProductCategory> productCList = new List<ProductCategory>();

            try
            {
                var command = connection.CreateCommand();
                command.CommandText = "SELECT Category_Id, Name FROM ProductCategory";
                connection.Open();
                command.Prepare();

                var dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    var productC = new ProductCategory();
                    productC.ProductCategory_Id = dataReader.GetInt32(0);
                    productC.Name = dataReader.GetString(1);
                    productCList.Add(productC);

                }

                dataReader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return productCList;
        }

        public ProductCategory GetByName(string name)
        {

            ProductCategory p = new ProductCategory();

            try
            {

                var command = connection.CreateCommand();

                command.CommandText = "SELECT Category_Id, Name FROM ProductCategory WHERE Name = @Name";

                var NameParam = command.CreateParameter();
                NameParam.ParameterName = "Name";
                NameParam.DbType = DbType.String;
                NameParam.Size = 100;
                NameParam.Value = name;
                command.Parameters.Add(NameParam);

                connection.Open();

                command.Prepare();

                var dataReader = command.ExecuteReader();

                while (dataReader.Read())
                {
                    p.ProductCategory_Id = dataReader.GetInt32(0);
                    p.Name = dataReader.GetString(1);
                }

                dataReader.Close();

                connection.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return p;

        }

        public ProductCategory GetByID(int id)
        {
            ProductCategory p = new ProductCategory();

            try
            {

                var command = connection.CreateCommand();

                command.CommandText = "SELECT Category_Id, Name FROM ProductCategory WHERE Category_Id = @Category_Id ";

                var IdParam = command.CreateParameter();
                IdParam.ParameterName = "Category_Id";
                IdParam.DbType = DbType.Int32;
                IdParam.Value = id;
                command.Parameters.Add(IdParam);

                connection.Open();

                command.Prepare();

                var dataReader = command.ExecuteReader();

                while (dataReader.Read())
                {
                    p.ProductCategory_Id = dataReader.GetInt32(0);
                    p.Name = dataReader.GetString(1);
                }

                dataReader.Close();

                connection.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return p;
        }

        public void Modify (ProductCategory productC)
        {
            try
            {
                var insertCommand = connection.CreateCommand();

                insertCommand.CommandText = "UPDATE ProductCategory SET Name = @Name WHERE Category_Id = @Category_Id";

                var CategoryIdParam = insertCommand.CreateParameter();
                CategoryIdParam.ParameterName = "Category_Id";
                CategoryIdParam.DbType = DbType.Int32;
                CategoryIdParam.Value = productC.ProductCategory_Id;
                insertCommand.Parameters.Add(CategoryIdParam);

                var NameParam = insertCommand.CreateParameter();
                NameParam.ParameterName = "Name";
                NameParam.DbType = DbType.String;
                NameParam.Size = 100;
                NameParam.Value = productC.Name;
                insertCommand.Parameters.Add(NameParam);


                connection.Open();

                insertCommand.Prepare();

                insertCommand.ExecuteNonQuery();

                connection.Close();



            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
