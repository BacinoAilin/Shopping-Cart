﻿using Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace Repositories
{
    public class UserRepository : IUserRepository
    {
        private IList<User> users = new List<User>();
        private static UserRepository instance = null;
        private IConnection connection = new Connection();
        public static IUserRepository GetInstance()
        {
            try
            {
                if (instance == null)
                    instance = new UserRepository();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return instance;
        }
        public void Add(User user)
        {
            try
            {

                var insertCommand = connection.CreateCommand();

                insertCommand.CommandText = "INSERT INTO Users(UserType_Id, Name, Email, Password) VALUES (@UserType_Id, @Name, @Email, @Password)";

                var UserType_IdParam = insertCommand.CreateParameter();
                UserType_IdParam.ParameterName = "UserType_Id";
                UserType_IdParam.DbType = DbType.Int32;
                UserType_IdParam.Value = user.UserType_Id;
                insertCommand.Parameters.Add(UserType_IdParam);

                var NameParam = insertCommand.CreateParameter();
                NameParam.ParameterName = "Name";
                NameParam.DbType = DbType.String;
                NameParam.Size = 100;
                NameParam.Value = user.Name;
                insertCommand.Parameters.Add(NameParam);

                var EmailParam = insertCommand.CreateParameter();
                EmailParam.ParameterName = "Email";
                EmailParam.DbType = DbType.String;
                EmailParam.Size = 100;
                EmailParam.Value = user.Email;
                insertCommand.Parameters.Add(EmailParam);

                var PassParam = insertCommand.CreateParameter();
                PassParam.ParameterName = "Password";
                PassParam.DbType = DbType.String;
                PassParam.Size = 100;
                PassParam.Value = user.Password;
                insertCommand.Parameters.Add(PassParam);

                connection.Open();

                insertCommand.Prepare();

                insertCommand.ExecuteNonQuery();

                connection.Close();


            }
            catch (Exception ex)
            {
                throw ex;
            }
          //  users.Add(user);
        }

        public void Delete(int id)
        {
            try
            {
                var command = connection.CreateCommand();

                command.CommandText = "DELETE FROM Users WHERE User_Id = @User_Id";

                var IdParam = command.CreateParameter();
                IdParam.ParameterName = "User_Id";
                IdParam.DbType = DbType.Int32;
                IdParam.Value = id;
                command.Parameters.Add(IdParam);

                connection.Open();

                command.Prepare();

                command.ExecuteNonQuery();

                connection.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public IList<User> GetAll()
        {

            IList<User> userList = new List<User>();

            try
            {
                var command = connection.CreateCommand();
                command.CommandText = "SELECT User_Id, UserType_Id, Name, Email, Password FROM Users";
                connection.Open();
                command.Prepare();

                var dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    var user = new User();
                    user.User_Id = dataReader.GetInt32(0);
                    user.UserType_Id = dataReader.GetInt32(1);
                    user.Name = dataReader.GetString(2);
                    user.Email = dataReader.GetString(3);
                    user.Password = dataReader.GetString(4);

                    userList.Add(user);

                }

                dataReader.Close();

                connection.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return userList;
        }

        public User GetByEmail(string email)
        {

           User p = new User();

            try
            {

                var command = connection.CreateCommand();

                command.CommandText = "SELECT User_Id, UserType_Id, Name, Email, Password FROM Users WHERE Email = @Email ";

                var emailParam = command.CreateParameter();
                emailParam.ParameterName = "Email";
                emailParam.DbType = DbType.String;
                emailParam.Size = 100;
                emailParam.Value = email;
                command.Parameters.Add(emailParam);

                connection.Open();

                command.Prepare();

                var dataReader = command.ExecuteReader();

                while (dataReader.Read())
                {
                    p.User_Id = dataReader.GetInt32(0);
                    p.UserType_Id = dataReader.GetInt32(1);
                    p.Name = dataReader.GetString(2);
                    p.Email = dataReader.GetString(3);
                    p.Password = dataReader.GetString(4);
                }

                dataReader.Close();

                connection.Close();


            }
            catch (Exception ex)
            {
                throw ex;
            }

            return p;

        }

        public User GetByPass(string pass)
        {

            User p = new User();

            try
            {

                var command = connection.CreateCommand();

                command.CommandText = "SELECT User_Id, UserType_Id, Name, Email, Password FROM Users WHERE Password = @Password";

                var PassParam = command.CreateParameter();
                PassParam.ParameterName = "Password";
                PassParam.DbType = DbType.String;
                PassParam.Size = 100;
                PassParam.Value = pass;
                command.Parameters.Add(PassParam);

                connection.Open();

                command.Prepare();

                var dataReader = command.ExecuteReader();

                while (dataReader.Read())
                {
                    p.User_Id = dataReader.GetInt32(0);
                    p.UserType_Id = dataReader.GetInt32(1);
                    p.Name = dataReader.GetString(2);
                    p.Email = dataReader.GetString(3);
                    p.Password = dataReader.GetString(4);
                }

                dataReader.Close();

                connection.Close();


            }
            catch (Exception ex)
            {
                throw ex;
            }

            return p;

        }
        //encapsula la lógica de la base de datos.
        public void Modify(User user)
        {
            try
            {
                var insertCommand = connection.CreateCommand();

                insertCommand.CommandText = "UPDATE Users SET UserType_Id = @UserType_Id, Name = @Name, Email = @Email, Password = @Password WHERE User_Id = @User_Id";

                var User_IdParam = insertCommand.CreateParameter();
                User_IdParam.ParameterName = "User_Id";
                User_IdParam.DbType = DbType.Int32;
                User_IdParam.Value = user.User_Id;
                insertCommand.Parameters.Add(User_IdParam);

                var UserType_IdParam = insertCommand.CreateParameter();
                UserType_IdParam.ParameterName = "UserType_Id";
                UserType_IdParam.DbType = DbType.Int32;
                UserType_IdParam.Value = user.UserType_Id;
                insertCommand.Parameters.Add(UserType_IdParam);

                var NameParam = insertCommand.CreateParameter();
                NameParam.ParameterName = "Name";
                NameParam.DbType = DbType.String;
                NameParam.Size = 100;
                NameParam.Value = user.Name;
                insertCommand.Parameters.Add(NameParam);

                var EmailParam = insertCommand.CreateParameter();
                EmailParam.ParameterName = "Email";
                EmailParam.DbType = DbType.String;
                EmailParam.Size = 100;
                EmailParam.Value = user.Email;
                insertCommand.Parameters.Add(EmailParam);

                var PassParam = insertCommand.CreateParameter();
                PassParam.ParameterName = "Password";
                PassParam.DbType = DbType.String;
                PassParam.Size = 100;
                PassParam.Value = user.Password;
                insertCommand.Parameters.Add(PassParam);

                connection.Open();

                insertCommand.Prepare();

                insertCommand.ExecuteNonQuery();

                connection.Close();


            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
   
}
