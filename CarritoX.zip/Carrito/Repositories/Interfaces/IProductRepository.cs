﻿using Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Repositories
{
    public interface IProductRepository
    {
        IList<Product> GetAll();
        void Add(Product product);
        Product GetByName(string name);
        void Delete(int id);
        Product GetByID(int id);
        void Modify(Product product);

        bool CategoryId(int id);

        int GetCategoryID(int id);

    }
}
