﻿using Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Repositories
{
    public interface IProductCategoryRepository
    {
        IList<ProductCategory> GetAll();
        void Add(ProductCategory productC);
        ProductCategory GetByName(string name);
        ProductCategory GetByID(int id);

        void Remove(int id);
        void Modify(ProductCategory productC);

    }
}
