﻿using Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Repositories
{
    public interface IUserRepository
    {
        IList<User> GetAll();
        void Add(User user);
        User GetByEmail(string email);
        User GetByPass(string pass);
        void Modify(User user);

        void Delete(int id);

    }
}
