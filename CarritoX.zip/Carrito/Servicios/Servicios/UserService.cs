﻿using Models;
using Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Servicios
{
    public class UserService : IUserService
    {
        private IUserRepository userRepository;

        
        public UserService()
        {
            userRepository = UserRepository.GetInstance();

        }
        public bool Add(User users)
        {
            var result = false;

            //if (userRepository.GetByEmail(users.Email) == null)
            //{
                userRepository.Add(users);
                result = true;
            //}
            return result;

        }

        public bool Delete(int id)
        {

            var result = false;
            if (userRepository.GetAll().Where(x => x.User_Id == id).FirstOrDefault() != null) // si existe la categoria que estoy buscando
            {
                userRepository.Delete(id);
                result = true;
            }
            return result; // true si borro, false si no borro.
        }

        public IList<User> GetAll()
        {
            return userRepository.GetAll();
        }

        public bool Login(string email, string pass)
        {
            try
            {
                bool result = false;
                User p = null;
                User z = null;

                if (userRepository.GetAll().Where(x => x.Email == email).FirstOrDefault() != null)
                {
                    p = userRepository.GetByEmail(email);

                    if (p.Password == pass)
                    {
                        z = userRepository.GetByPass(pass);
                        result = true;
                    }

                }
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }


        }

        public void Modify(User user)
        {
            userRepository.Modify(user);
        }
    }
}
