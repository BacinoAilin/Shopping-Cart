﻿using Models;
using Repositories;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace Servicios
{
    public class ProductCategoryService : IProductCategoryService
    {
        private IProductCategoryRepository productCategoryRepository = new ProductCategoryRepository();
        private IProductRepository productRepository = new ProductRepository(); 
        public bool Add(ProductCategory productC)
        {
            try
            {
                var result = false;
                //No puedo agregar dos categorías que tengan el mismo name.
                if (productCategoryRepository.GetAll().Where(x => x.Name == productC.Name).FirstOrDefault() == null)
                {
                    if (productC != null)
                    {
                        productCategoryRepository.Add(productC);
                        result = true;
                    }
                }
                return result;
                //Si lo logro añadir retorno true, si no lo logro retorno false -> Lógica de negocio dentro del servicio.
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public bool Delete(int id)
        {
           var result = false;

            //if (productCategoryRepository.GetAll().Where(x => x.ProductCategory_Id == id).FirstOrDefault() == null) // si existe la categoria que estoy buscando
            //{
                if (productRepository.CategoryId(id) == false)
                {
                    productCategoryRepository.Remove(id);
                    result = true;
                }
                
            //}

            return result; // true si borro, false si no borro.
        }

        
        public IList<ProductCategory> GetAll()
        {
            return productCategoryRepository.GetAll();
        }

        public ProductCategory GetById(int id)
        {
            try
            {
                ProductCategory p = null;

                if (productCategoryRepository.GetAll().Where(x => x.ProductCategory_Id == id).FirstOrDefault() == null)
                {
                    p = productCategoryRepository.GetByID(id);
                }

                return productCategoryRepository.GetByID(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public ProductCategory GetByName(string name)
        {
            try
            {
                ProductCategory p = null;

                if (productCategoryRepository.GetAll().Where(x => x.Name == name).FirstOrDefault() == null)
                {
                    p = productCategoryRepository.GetByName(name);
                }

                return productCategoryRepository.GetByName(name);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public void Modify(ProductCategory productC)
        {
            productCategoryRepository.Modify(productC);
        }
    }
}
