﻿using Models;
using Repositories;
using System;
using System.Collections.Generic;
using System.Text;

namespace Servicios
{
    public class UserTypeService : IUserTypeService
    {
        private IUserTypeRepository userTypeRepository;

        public UserTypeService()
        {
            userTypeRepository = UserTypeRepository.GetInstance();
        }
        public IList<UserType> GetAll()
        {
            return userTypeRepository.GetAll();
        }

    }
}
