﻿using Models;
using Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Servicios
{
    public class ProductService: IProductService
    {
        private IProductRepository productRepository;

        public ProductService()
        {
            productRepository = ProductRepository.GetInstance();
        }
        public bool Add(Product product)
        {
            var result = false;
           //No puedo agregar dos productos que tengan el mismo name.
           //if(productRepository.GetByName(product.Name) == null)
           // {
           //     productRepository.Add(product);
           //     result = true;
           // }
           // return result;

            if (productRepository.GetAll().Where(x => x.Name == product.Name).FirstOrDefault() == null)
            {
                productRepository.Add(product);
                result = true;

            }
            return result;


            //Si lo logro añadir retorno true, si no lo logro retorno false -> Lógica de negocio dentro del servicio.
        }

        
        public IList<Product> GetAll()
        {
            //Acá hago un return de product repository get all. 
            // El product repository es el que se conecta a la base de datos, y le pide los datos.
            return productRepository.GetAll();

        }

        public bool Delete(int id)
        {
            var result = false;

            if (productRepository.GetAll().Where(x => x.Id == id).FirstOrDefault() != null)
            {
                productRepository.Delete(id);
                result = true;
            }
            return result;
        }

        public Product GetById(int id)
        {
            try
            {
                Product p = null;

                if (productRepository.GetAll().Where(x => x.Id == id).FirstOrDefault() == null)
                {
                    p = productRepository.GetByID(id);
                }

                return productRepository.GetByID(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
           

        }

        public int GetCategoryId (int id)
        {
            return productRepository.GetCategoryID(id);
        }

        public Product GetByName(string name)
        {
            try
            {
                Product p = null;

                if (productRepository.GetAll().Where(x => x.Name == name).FirstOrDefault() == null)
                {
                    p = productRepository.GetByName(name);
                }

                return productRepository.GetByName(name);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public void Modify(Product product)
        {
            productRepository.Modify(product);
        }
    }
}
