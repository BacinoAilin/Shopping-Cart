﻿using Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Servicios
{
   public interface IUserService
    {
        bool Add(User users);
        IList<User> GetAll();
        bool Delete(int id);

        void Modify(User user);

        bool Login(string email, string pass);

    }
}
