﻿using Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Servicios
{
    public interface IUserTypeService
    {
        IList<UserType> GetAll();
    }
}
