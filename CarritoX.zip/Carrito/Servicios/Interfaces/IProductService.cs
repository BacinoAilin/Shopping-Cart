﻿using Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Servicios
{
    public interface IProductService
    {
       bool Add(Product product);
       IList<Product> GetAll();
       bool Delete(int id);
       Product GetById(int id);
       void Modify(Product product);
       Product GetByName(string name);
       int GetCategoryId(int id);
    }
}
