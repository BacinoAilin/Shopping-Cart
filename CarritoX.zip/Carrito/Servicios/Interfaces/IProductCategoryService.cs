﻿using Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Servicios
{
    public interface IProductCategoryService
    {
        bool Add(ProductCategory productC);
        IList<ProductCategory> GetAll();
        bool Delete(int id);
        ProductCategory GetById(int id);
        ProductCategory GetByName(string name);
        void Modify(ProductCategory productC);
    }
}
