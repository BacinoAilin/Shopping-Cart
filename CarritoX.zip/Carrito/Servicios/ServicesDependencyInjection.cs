﻿using Microsoft.Extensions.DependencyInjection;
using Repositories;
using System;
using System.Collections.Generic;
using System.Text;

namespace Servicios
{
    public static class ServicesDependencyInjection
    {
        public static IServiceCollection ConfigureServices(this IServiceCollection Servicios)
        {
            Servicios.AddTransient<IProductRepository, ProductRepository>();
            Servicios.AddTransient<IProductCategoryRepository, ProductCategoryRepository>();
            //Servicios.AddTransient<IUserRepository, IUserRepository>();

            return Servicios;
        }
    }
}
