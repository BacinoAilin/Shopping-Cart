﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Carrito.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models;
using Servicios;

namespace Carrito.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private IList<User> users = new List<User>();
        private IUserService userService;

        public UserController()
        {
            userService = new UserService();
        }

        [Route("GetAll")]
        [HttpGet]

        public IActionResult Get()
        {
            var users = userService.GetAll();
            return Ok(users);
        }

        [Route("Add")]
        [HttpPost]

        public IActionResult Save(User user)
        {
            if (userService.Add(user))
            {
                return Ok("User successfully added"); // El Ok() es un 200, lo que solicité se ejecutó.
            }
            return BadRequest("This user already exists");

        }

        [Route("Login")]
        [HttpPost]
        public IActionResult Login(string Email, string Pass)
        {
            if (userService.Login(Email, Pass) != false)
            {
                return Ok("You have login");
            }
            return BadRequest("Wrong Email or Password");

        }

        [Route("Modify")]
        [HttpPost]

        public void Modify(User user)
        {
            userService.Modify(user);
        }

        [Route("Delete")]
        [HttpPost]
        public IActionResult Delete(int id)
        {
            if (userService.Delete(id) == true)
            {
                return Ok("User successfully deleted");
            }
            return BadRequest("User id is wrong. Cannot delete");
        }

    }
}