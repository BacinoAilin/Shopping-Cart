﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Models;
using Servicios;

namespace Carrito.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserTypeController : ControllerBase
    {
        private IUserTypeService usersTypeService;

        public UserTypeController()
        {
            usersTypeService = new UserTypeService();
        }

        [Route("GetAll")]
        [HttpGet]
        public IActionResult Get()
        {
            var userType = usersTypeService.GetAll();
            return Ok(userType);
        }
    }
}
