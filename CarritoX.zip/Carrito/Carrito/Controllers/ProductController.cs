﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models;
using Servicios;

namespace Carrito.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private IProductService productService;
        

        public ProductController()
        {
           productService = new ProductService();
        }

        [Route("GetAll")]
        [HttpGet]
        public IActionResult Get()
        {
            var products = productService.GetAll();
            return Ok(products);
        }

        [Route("GetbyID")]
        [HttpGet]
        public IActionResult GetbyID(int id)
        {
            var products = productService.GetById(id);
            return Ok(products);
        }

        [Route ("GetByName")]
        [HttpGet]

        public IActionResult GetByName(string name)
        {
            var products = productService.GetByName(name);
            return Ok(products);
        }

        [Route("Add")]
        [HttpPost]
           
        public IActionResult Save (Product product)
        {
            if(productService.Add(product))
            {
                return Ok("Product successfully added"); // El Ok() es un 200, lo que solicité se ejecutó.
            }
            return BadRequest("This Product already exists");
           
        }

        [Route("Delete")]
        [HttpPost]
       public IActionResult Delete(int id)
        {
           if(productService.Delete(id))
            {
                return Ok("Product succesfully removed");

            }
            return BadRequest("This product doesn't exists, or couldn't be removed");

        }

        [Route("Modify")]
        [HttpPost]

        public void Modify(Product product)
        {
           productService.Modify(product);
        }

    }
}