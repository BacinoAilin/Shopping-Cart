﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Models;
using Servicios;

namespace Carrito.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductCategoryController : ControllerBase
    {

            private IProductCategoryService productCategoryService;

            public ProductCategoryController()
            {
            productCategoryService = new ProductCategoryService();
            }

         
            [Route("GetAll")]
            [HttpGet]
             public IActionResult Get()
            {
                var productsC = productCategoryService.GetAll();
                return Ok(productsC);
            }
            
            [Route("GetbyID")]
            [HttpGet]
            public IActionResult GetById(int id)
            {
                var productsC = productCategoryService.GetById(id);
                return Ok(productsC);
            }

            [Route("GetByName")]
            [HttpGet]

            public IActionResult GetByName(string name)
            {
                var productsC = productCategoryService.GetByName(name);
                return Ok(productsC);
            }

            [Route("Add")]
            [HttpPost]

            public IActionResult Save(ProductCategory productC)
            {
                if (productCategoryService.Add(productC))
                {
                    return Ok("Category successfully added"); // El Ok() es un 200, lo que solicité se ejecutó.
                }
                return BadRequest("This Category already exists");

            }
            
            [Route("Delete")]
            [HttpPost]
            public IActionResult Delete(int id)
            {
                if (productCategoryService.Delete(id) == true)
                {
                    return Ok("Category successfully deleted");
                }
                return BadRequest("This category contains products. Cannot delete");
            }

            [Route("Modify")]
            [HttpPost]

            public void Modify(ProductCategory productC)
            {
                productCategoryService.Modify(productC);
            }


    }
    
}
