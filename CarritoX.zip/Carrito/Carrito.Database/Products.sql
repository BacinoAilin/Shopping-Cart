﻿CREATE TABLE [dbo].[Products]
(
	[Id] INT NOT NULL IDENTITY(1,1),
	[Category_Id] INT NOT NULL,
	[Name] VARCHAR (100) NOT NULL,
	[Description] VARCHAR (200) NOT NULL,
	[Price] FLOAT NOT NULL,
	[Image_Url] VARCHAR (200) NOT NULL,
	CONSTRAINT PK_Products PRIMARY KEY ([Id]),
	CONSTRAINT FK_Products_Category FOREIGN KEY (Category_Id) REFERENCES ProductCategory(Category_Id)
)
