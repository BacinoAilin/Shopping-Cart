﻿CREATE TABLE [dbo].[ProductCategory]
(
	[Category_Id] INT NOT NULL IDENTITY(1,1),
	[Name] VARCHAR (100) NOT NULL,
	CONSTRAINT PK_CategoryProduct PRIMARY KEY ([Category_Id])
)
