﻿CREATE TABLE [dbo].[UserType]
(
	[UserType_Id] INT NOT NULL IDENTITY(1,1),
	[Name] VARCHAR (100) NOT NULL,
	CONSTRAINT PK_UserType PRIMARY KEY ([UserType_Id])
)
