﻿CREATE TABLE [dbo].[Users]
(
	[User_Id] INT NOT NULL IDENTITY(1,1),
    [UserType_Id] INT NOT NULL,
    [Name] VARCHAR (100) NOT NULL,
    [Email] VARCHAR (100) NOT NULL,
    [Password] VARCHAR (100) NOT NULL,
    CONSTRAINT PK_Users PRIMARY KEY ([User_Id]),
	CONSTRAINT FK_Users_Type FOREIGN KEY (UserType_Id) REFERENCES UserType(UserType_Id)
 
)
