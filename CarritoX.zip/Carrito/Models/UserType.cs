﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models
{
    // Esta clase es fija. Los tipos de usuario van a ser "Admin" y "Client"
    public class UserType
    {
        public int UserType_Id { get; set; }
        public string Name { get; set; }
    }
}
