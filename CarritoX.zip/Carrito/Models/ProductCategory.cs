﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models
{
    public class ProductCategory
    {

        public int ProductCategory_Id { get; set; }
        public string Name { get; set; }
    }
}
